import { existsSync } from 'node:fs';
import { relative, resolve, sep } from 'node:path';
import { packageDir, packages, root } from '../config.ts';
import { files, json } from '../lib/fs.ts';

interface Manifest {
    readonly version?: string;
}

const forbidden = new Set(['.cjs', '.html', '.js', '.jsx', '.mjs']);
const generated = [
    resolve(root, '.build'),
    resolve(root, 'node_modules'),
    resolve(packageDir, 'locales'),
    ...packages.flatMap((pkg) => [
        resolve(packageDir, pkg.id, 'dist'),
        resolve(packageDir, pkg.id, 'src'),
        resolve(packageDir, pkg.id, 'typings'),
    ]),
];

function under(path: string, parent: string): boolean {
    return path === parent || path.startsWith(`${parent}${sep}`);
}

export function checkRepo(): void {
    const bad = files(root).filter((path) => {
        if (generated.some((dir) => under(path, dir))) {
            return false;
        }
        const match = /\.[^.]+$/u.exec(path);
        return match !== null && forbidden.has(match[0]);
    });
    if (bad.length > 0) {
        throw new Error(`Tracked-source candidates contain JavaScript or HTML:\n${bad.map((path) => relative(root, path)).join('\n')}`);
    }

    for (const name of ['src', 'docs']) {
        if (!existsSync(resolve(root, name))) {
            throw new Error(`Missing root ${name}/ directory`);
        }
    }
    if (files(resolve(root, 'docs')).some((path) => !path.endsWith('.md'))) {
        throw new Error('docs/ must contain Markdown only');
    }

    for (const pkg of packages) {
        const manifest = json<Manifest>(resolve(packageDir, pkg.id, 'package.json'));
        if (manifest.version !== '5.0.0') {
            throw new Error(`${pkg.name} must be version 5.0.0`);
        }
    }
}
