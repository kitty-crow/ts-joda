# Compatibility

The refactor changes repository organisation and implementation language, not the consumer-facing package contract.

## Preserved

- Package names for core, extra, timezone, locale and prebuilt locale packages.
- Root exports and exported symbol names.
- UMD package entry files used by `main`.
- ESM files used by `module`.
- Core CommonJS compatibility output.
- Minified browser globals: `JSJoda`, `JSJodaExtra`, `JSJodaTimezone` and `JSJodaLocale`.
- Declaration entry files under `typings/`.
- Published `src/` deep-import paths, generated from the strict TypeScript source.
- Timezone range and empty distribution filenames.
- Plug-in registration behaviour and runtime value shapes.

## Repository versus package layout

The repository has one canonical source tree at `src/`. Package-local `src/`, `dist/`, `typings/`, README and licence files are generated during `npm run build` and ignored by Git. This keeps development organised without removing historical npm paths.

## Version

The refactor landmark versions the root and every maintained package as `5.0.0`. Future meaningful landmarks must increment versions normally and together where the compatibility surface changes.
